from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")

def landing_page():
	return render_template("landing_page.html")

@app.route("/projects")

def projects_page():
	return render_template("projects_page.html")

@app.route("/about")

def about_page():
	return render_template("about_page.html")

app.run(debug=True)